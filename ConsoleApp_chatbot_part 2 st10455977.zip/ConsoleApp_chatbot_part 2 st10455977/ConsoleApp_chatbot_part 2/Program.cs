﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Text;
using System.Threading;

class CyberSecurityChatbot
{
    static Dictionary<string, List<string>> topicResponses = new Dictionary<string, List<string>>()
    {
        { "password", new List<string> { "Make sure to use strong, unique passwords for each account.", "Avoid using personal information in your passwords.", "Use a password manager to keep track of complex passwords." } },
        { "scam", new List<string> { "Be cautious of emails asking for personal info. Scammers can mimic trusted sources.", "Always verify the sender before clicking on any links.", "Scams often use urgency to trick you. Take your time before reacting." } },
        { "privacy", new List<string> { "Regularly review the privacy settings on your social media accounts.", "Use end-to-end encrypted messaging apps.", "Be careful what personal info you share online." } },
        { "phishing", new List<string> { "Be cautious of emails with urgent or threatening language.", "Don't click links from unknown senders.", "Check URLs carefully for misspellings or suspicious domains." } }
    };

    static HashSet<string> sentimentWords = new HashSet<string> { "worried", "curious", "frustrated" };

    static string userName = "";
    static string userInterest = "";

    static void Main(string[] args)
    {
        // Play greeting and show ASCII logo
        PlayVoiceGreeting();
        DisplayAsciiLogo();

        Console.WriteLine("👋 Welcome to the CyberSecurity Chatbot!");
        Console.Write("Before we start, what's your name? ");
        userName = Console.ReadLine();

        Console.WriteLine($"Nice to meet you, {userName}! Ask me anything about cybersecurity.");

        while (true)
        {
            Console.Write("\nYou: ");
            string input = Console.ReadLine().ToLower();

            if (input.Contains("bye") || input.Contains("exit"))
            {
                Console.WriteLine("Chatbot: Stay safe online! Goodbye.");
                break;
            }

            // Check for sentiment
            if (DetectSentiment(input, out string sentimentResponse))
            {
                Console.WriteLine($"Chatbot: {sentimentResponse}");
                continue;
            }

            // Check for keyword recognition
            bool recognized = false;
            foreach (var topic in topicResponses.Keys)
            {
                if (input.Contains(topic))
                {
                    recognized = true;
                    if (topic == "privacy" && string.IsNullOrEmpty(userInterest))
                    {
                        userInterest = "privacy";
                        Console.WriteLine("Chatbot: Great! I'll remember that you're interested in privacy. It's a crucial part of staying safe online.");
                    }
                    else
                    {
                        string response = GetRandomResponse(topicResponses[topic]);
                        Console.WriteLine($"Chatbot: {response}");
                    }
                    break;
                }
            }

            // Check for follow-up on stored interest
            if (!recognized && !string.IsNullOrEmpty(userInterest) &&
                (input.Contains("more") || input.Contains("details")))
            {
                Console.WriteLine($"Chatbot: As someone interested in {userInterest}, you might want to review the security settings on your accounts.");
                recognized = true;
            }

            if (!recognized)
            {
                Console.WriteLine("Chatbot: I'm not sure I understand. Can you try rephrasing?");
            }
        }
    }

    static void PlayVoiceGreeting()
    {
        try
        {
            var myPlayer = new SoundPlayer();
            myPlayer.SoundLocation = @"C:\Users\lekga\OneDrive\Desktop\ConsoleApp1\voice_greeting.wav.wav";
            myPlayer.PlaySync();

            Console.WriteLine("Welcome to Besh Cybersecurity Awareness chatbot!");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error playing the voice greeting: " + ex.Message);
        }
    }

    static void DisplayAsciiLogo()
    {
        Console.WriteLine(@"
   ____  _____  _____  _____ 
  | __ )| ____|| ____|| ____|
  |  _ \|  _|  |  _|  |  _|  
  | |_) | |___ | |___ | |___ 
  |____/|_____||_____||_____|
        ");
    }

    static string GetRandomResponse(List<string> responses)
    {
        Random rnd = new Random();
        int index = rnd.Next(responses.Count);
        return responses[index];
    }

    static bool DetectSentiment(string input, out string response)
    {
        response = "";
        if (input.Contains("worried"))
        {
            response = "It's completely understandable to feel that way. Let me share some tips to help you stay safe.";
            return true;
        }
        else if (input.Contains("curious"))
        {
            response = "Curiosity is a great mindset for learning about cybersecurity! Ask me anything.";
            return true;
        }
        else if (input.Contains("frustrated"))
        {
            response = "Cybersecurity can be overwhelming at times. I'm here to help make it simpler.";
            return true;
        }
        return false;
    }
}
